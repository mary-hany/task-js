
let phones = [];
let prices = [];
 

function addphone() {
  let phone = prompt("Add phone");
  phones.push(phone);
  let price = +prompt("Add price");
  prices.push(price);
  console.clear();
  phoneNum();
}

function phoneNum() {
    phones.forEach((phone, index) => {
      console.log(`${index + 1}- ${phone} ==>(${prices[index]})$ `);
    });
  }

  
  function deletephone() {
    let phoneIndex = +prompt("Enter phone you want to delete ");
    let del=phoneIndex - 1;
    phones.splice(del, 1);
    prices.splice(phoneIndex - 1, 1);
    console.clear();
    phoneNum();
  }
  

  function update() {
    let phone  = +prompt("Enter phone you want to update ");
    let phoneIndex = phone-1;
    let newPhone = prompt("Enter new phone");
    let newPrice = +prompt("Enter new price");
    phones[phoneIndex - 1] = newPhone;
    prices[phoneIndex - 1] = newPrice;
    phones.splice(phoneIndex,1, newPhone,newPrice)
    console.clear();
    phoneNum();
  }